# GEPA Optimization Report — academic-research skill v3.0.0 → v3.3.0

Optimizer: GEPA-style reflective mutation (gepa 0.1.4 runtime, `optimize_anything`-equivalent
loop executed in resumable chunks). Candidate = the complete `SKILL.md` file.
Evaluator = structural gate → 2 simulated agent runs per scenario → one dual-grading
LLM-as-judge call against a weighted checkable rubric.

## 1. Setup

| Component | Choice |
|---|---|
| Mode | Generalization: 4 train scenarios (optimize) + 2 val scenarios (selection) |
| Scenarios | S1 literature-search, S2 gap-audit, S3 supplied-sources synthesis, S6 resume (train); S4 method-arena, S5 claim-verification (val) — each mirrors one route of the skill's own front-door table |
| Judge | Strict 0/0.5/1 scoring per weighted rubric item; anti-pattern penalties (fabricated citations, snippet-as-proof, gap-on-low-yield, source-boundary violation, certainty manufacturing) |
| Structural gate | Frontmatter validity, `name: academic-research` preserved, referenced package files exist, ≤32,000 chars, ≥8 section headers (rejects "answer-style" candidates before any LLM spend) |
| Budget | 8 reflective proposals, 34 example-evals (+10 in final validation) |
| Reflection LM / judge / agent | environment LLM via `z-ai` CLI bridge with rate-limit backoff |

## 2. Measured result (full 6-scenario evaluation, N=2 agent runs per eval)

| Scenario | v3.0.0 (seed) | v3.3.0 (final) | Δ |
|---|---|---|---|
| S1 literature search | 0.550 | 0.850 | **+0.300** |
| S2 gap audit | 0.850 | 0.863 | +0.013 |
| S3 supplied-sources synthesis | 0.637 | 0.887 | **+0.250** |
| S4 method arena | 0.575 | 0.575 | 0.000 |
| S5 claim verification | 0.738 | 0.725 | −0.013 (within noise) |
| S6 resume from checkpoint | 0.588 | 0.825 | **+0.237** |
| **Mean** | **0.656** | **0.787** | **+0.131 (+20%)** |

## 3. What the optimization found (and what shipped)

**Round 1 (pure search).** 8 proposals, best on the valset = candidate `e92ef1f8708a`
(val 0.888 vs seed 0.656). Inspection showed this winner was the seed with sections
16–24 truncated (−30% length): the tighter file made simulated agents comply better
on the val scenarios. It had NOT learned new content.

**Coverage audit.** Full 6-scenario evaluation exposed the valset's blind spot: the
truncated winner collapsed on lit-review discipline (S3 = 0.20; lost `[CITATION NEEDED]`,
supplied-sources boundary) and resume (S6 = 0.46). Full-coverage best was instead
candidate `066cae05a410` (0.740 mean), which had ADDED: Boolean concept-group search
strategy, a 5-step gap-audit chain (categorize → ESTABLISHED/SEARCH-LIMITED →
falsification condition → evidence-state labeling → PhD-stakes warning), explicit
inclusion/exclusion criteria, and an Anti-Pattern Guards section.

**Round 2 (graft, the skill's own Arena move).** Final v3.3.0 = base `066cae05a410`
+ restored seed disciplines (design discipline with SUPPORTED/UNSUPPORTED claims,
literature-review discipline incl. supplied-sources boundary and `not reported`
matrix rule, originality labels, stop rules, reflect, quality gate, portable host
rules, completion contract, RESEARCH_STATE rules). Schema version normalized to
"3.0" to match `templates/research-state.yaml`. All 17 key concepts verified retained.

## 4. Honest caveats

- Judge/agent stochasticity is substantial (same seed drew 0.2–0.95 on early N=1
  evals). Final numbers use N=2 averaging; residual noise is roughly ±0.05-0.1 per
  scenario. S4's apparent 1.0 in the search loop was a favorable draw — the final
  version does not actually improve method-arena behavior (0.575, flat).
- Deviation from stock GEPA: the loop was re-implemented as a resumable chunked
  runner (sandbox kills background processes; gepa 0.1.4 has no resume) using gepa's
  own proposal extraction and the same reflective-mutation/acceptance/selection
  semantics, minus Pareto-frontier bookkeeping and the merge proposer.
- The valset (2 scenarios) under-covered the skill's surface — caught and corrected
  by the full-coverage audit; a future run should optimize against all 6+ scenarios.

## 5. Package

```
academic-research-skill-v3-optimized/
├── SKILL.md                  ← v3.3.0, the optimized file
├── README.md
├── OPTIMIZATION-REPORT.md    ← this report
├── references/               (unchanged: stages, evidence-protocol, handoff, playbooks)
└── templates/                (unchanged: research-state.yaml, decision-log.tsv)
```

## 6. Re-running

```
cd /home/z/my-project/scripts
# dataset/scenarios: ars_dataset.py | evaluator: optimize_skillpack.py
uv run python mini_gepa.py 460        # chunked search loop (resumable)
uv run python validate_final.py 460   # full-coverage validation (resumable)
uv run python graft_final.py          # rebuild the grafted final SKILL.md
```
