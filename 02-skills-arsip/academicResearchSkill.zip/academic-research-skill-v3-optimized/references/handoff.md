# Handoff and Recall Contract

## Research state

Use `RESEARCH_STATE` as the authoritative compact state between sessions or
agents. See `templates/research-state.yaml`.

## Resume order

1. Read the latest state.
2. Read the latest decision-trail entries.
3. Locate the last verified checkpoint.
4. Identify done vs pending work.
5. Re-check only critical inherited claims.
6. Continue from the smallest unfinished stage.

Do not redo completed work merely because the next agent was not present for it.

## Thread statuses

Use one where helpful:

`[verified]`
`[in flight]`
`[planned, not started]`
`[inconclusive]`
`[blocked]`
`[rejected]`

## Checkpoint contents

A checkpoint records:
- current stage;
- done predicate status;
- confirmed findings;
- candidate gaps;
- decisions made;
- contradictions;
- verification needed;
- artifacts;
- next move.
