# 13 Academic Research Stages

The original 13-stage guide remains the content backbone. Execute only the stages
needed by the routed task.

## 1. Map the Field
Map themes, theories, methods, established findings, debates, and emerging
directions. End with promising research areas while separating evidence from
inference.

## 2. Identify Genuine Research Gaps
Test contradictions, overlooked populations/contexts, missing variables,
outdated assumptions, methodological weaknesses, and other defensible gap
types. State evidence needed to confirm each candidate gap.

## 3. Generate Focused Research Topics
Turn a broad interest into feasible topics that specify population, context,
phenomenon/variables, method, resources, and constraints.

## 4. Develop Research Questions
Create a primary question and supporting questions. For every question identify
required data, analysis, and risks such as breadth, leading wording,
unfeasibility, or causal overreach.

## 5. Build a Search Strategy
Create concept groups, synonyms, Boolean strings, database-specific syntax,
inclusion/exclusion criteria, dates, languages, source types, and broad/narrow
searches. Define rules for over- and under-retrieval.

## 6. Screen Research Sources
Classify supplied titles/abstracts as Include, Maybe, or Exclude. Give reasons
based on relevance, evidence role/quality, population, method, and recency where
relevant. Do not infer full-text details from abstracts.

## 7. Create a Synthesis Matrix
Use the supplied studies to populate citation, aim, theory, sample, method,
variables/themes, findings, limitations, contradictions, relevance, and possible
gaps. Use `not reported` when absent.

## 8. Map Academic Debates
Group findings by agreement, partial agreement, and conflict. Test whether
population, context, definitions, measurement, method, sample, or time period
could explain divergence.

## 9. Choose a Theoretical Framework
Compare frameworks by concepts, explanatory role, fit, observable implications,
data/analysis implications, strengths, limitations, and risk of forced use.

## 10. Select a Research Method
Compare suitable designs on sampling, data collection, sample needs, analysis,
feasibility, strengths, limitations, ethical risk, and supported/unsupported
claims.

## 11. Test Originality
Compare the proposed study against existing evidence across population, context,
phenomenon/variables, data, method, theory, measurement, and application. Avoid
unverified priority claims.

## 12. Outline the Literature Review
Build thematic sections with purpose, central argument, studies to compare,
debate, evidence gap, and transition. End with an evidence-derived gap
statement.

## 13. Draft the Literature Review
Using the allowed evidence boundary, synthesize by theme/debate, compare findings
and methods, evaluate limitations, preserve uncertainty, and establish the gap.
Use `[VERIFY]` or `[CITATION NEEDED]` where support is missing.
