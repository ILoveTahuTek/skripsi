# Evidence Protocol

## Discovery vs verification

Discovery tools find candidate sources. Verification inspects the underlying
source when the claim matters.

## Claim chain

`claim → source → support → interpretation → confidence`

## Verification priority

Verify directly when a claim:
- changes the research gap;
- changes topic selection;
- changes theory/method choice;
- affects safety, ethics, cost, or feasibility;
- is central to the literature-review argument;
- is used to claim originality.

## Contradiction handling

Never erase conflict by averaging it into consensus. Compare population,
context, operational definitions, measurement, design, sample, analysis, and
time period.

## Unavailable evidence

Use `VERIFY` or `UNKNOWN`. If inability to access the source prevents the finish
condition, mark the result `INCONCLUSIVE`.

## User source boundary

`supplied sources only` means no silent supplementation and no guessing missing
bibliographic or empirical details.
