# Research Playbooks

These are reusable execution recipes adapted from the structural ideas in
pstack. They are not vendor-specific commands.

## Investigate

Use for read-only questions.

1. Frame the exact question and finish condition.
2. Assess complexity.
3. For complex questions, fan out 2–4 independent evidence slices.
4. Verify important claims in primary/authoritative sources.
5. Synthesize with evidence labels.
6. Report unresolved uncertainty.

Output: cited research brief + state checkpoint.

## Source Swarm

Use when literature discovery or verification has independent coverage slices.

1. Define partition and N.
2. Give every worker the same output contract.
3. Run slices in parallel.
4. Aggregate, deduplicate, and reconcile.
5. Inspect evidence behind high-impact claims.

## Gap Audit

Use when a research gap is central.

1. Collect evidence for the proposed gap.
2. Search explicitly for counter-evidence.
3. Identify whether the gap is contradiction, context, population, variable,
   method, measurement, theory, replication, or implementation.
4. Ask what would falsify it.
5. Upgrade only if evidence survives the audit.

## Research Interrogation

Use adversarial reviewers to attack the proposed question/gap/design.

Rubric: evidence, alternative explanations, construct validity, measurement,
method fit, feasibility, ethics, external validity, novelty claims.

Synthesize into ACT / CONSIDER / NOTED / DISMISSED.

## Topic Arena

Run at least two structurally different topic candidates through one rubric.
Evaluate question fit, contribution, data access, feasibility, risk, and
verification burden. Graft useful elements only after selecting a coherent base.

## Theory Arena

Compare theoretical frameworks with the same rubric. Require each candidate to
state constructs, explanatory mechanism, observable implications, and data/
analysis consequences.

## Method Arena

Compare designs on question fit, sampling, measurement, analysis, feasibility,
ethics, and claim boundaries. The winning design is not a score; it is the design
whose fit and constraints are best supported for the user's stated goal.

## Evidence Verification

Trace a consequential claim to the underlying source and exact supporting
location. If the source does not establish the claim, rewrite or downgrade it.

## Literature Draft

Sequence:
`matrix → debate map → thematic outline → draft → citation audit → gap audit`

Do not draft from an unverified source list when the user expects evidence-based
writing.

## Research Run

For large multi-phase work:

`frame → ground → plan → execute units → verify each unit → checkpoint → resume
or stop`

Set an explicit stop predicate and record major decisions.

## Reflect

After a difficult run, extract only lessons that would alter future behavior.
Classify them ACCEPTED / REJECTED / BACKLOG before promoting them to durable
process rules.
