# Academic Research Skill v3.3.0

A portable academic research skill based on the original 13-stage research
prompt guide, strengthened with workflow architecture adapted from Cursor's
pstack plugin.

## What was adapted

- **Front-door routing**: one entry point selects the smallest useful playbook.
- **Complexity gate**: simple questions stay single-agent; complex evidence work
  can fan out.
- **Swarm**: parallelize independent research slices with a strict worker
  contract and parent reconciliation.
- **Interrogate**: adversarial review of gaps, questions, methods, theory, and
  originality claims.
- **Arena**: compare structurally different candidate topics/theories/methods,
  then select a coherent base and graft useful elements.
- **Prove it works**: conclusions are verified against actual source material,
  not summaries or agent self-reports.
- **Sequence verifiable units**: search/screen/extract/draft in small checked
  batches instead of deferring all verification to the end.
- **Recall**: resume from a durable checkpoint without rebuilding the project
  from scratch.
- **Decision trail**: keep a compact auditable record of decisions and evidence.
- **Research lever**: automate repeated research operations with rerunnable,
  reviewable artifacts.
- **Reflect**: convert only durable lessons into future process rules.
- **Progressive disclosure**: stage details, evidence rules, playbooks, and state
  templates live in `references/` and `templates/`.

## Why it is not a direct copy

pstack is an engineering workflow. This package preserves its useful structural
principles while translating code-specific ideas into academic concepts:
verification becomes source verification; design review becomes theory/method
review; worktrees/PRs become research-state artifacts and checkpoints; and code
quality rubrics become evidence/design validity rubrics.

## Version history

- **3.3.0** — GEPA-optimized: added Boolean concept-group search strategy, 5-step
  gap-audit chain (SEARCH-LIMITED vs ESTABLISHED, falsification, PhD-stakes),
  explicit inclusion/exclusion criteria, Anti-Pattern Guards; restored and merged
  all v3.0 discipline sections. Mean evaluated behavior +20% across six scenario
  families (see OPTIMIZATION-REPORT.md).
- **3.0.0** — original pstack-adapted architecture.

## Package

```text
academic-research-skill-v3/
├── SKILL.md
├── README.md
├── references/
│   ├── stages.md
│   ├── evidence-protocol.md
│   ├── handoff.md
│   └── playbooks.md
└── templates/
    ├── research-state.yaml
    └── decision-log.tsv
```

## Portability

The package does not require Cursor, a particular model, or proprietary
subagent parameters. Hosts may map the generic concepts to their own tool
syntax.
